from flask import Flask, render_template, request, send_file
from werkzeug.utils import secure_filename
import os
from PyPDF2 import PdfReader

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
CONVERTED_FOLDER = 'converted'

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(CONVERTED_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/convert', methods=['POST'])
def convert():
    if 'file' not in request.files:
        return 'No file part'

    file = request.files['file']
    if file.filename == '':
        return 'No selected file'

    filename = secure_filename(file.filename)
    pdf_path = os.path.join(UPLOAD_FOLDER, filename)
    file.save(pdf_path)

    txt_filename = filename.rsplit('.', 1)[0] + '.txt'
    txt_path = os.path.join(CONVERTED_FOLDER, txt_filename)

    try:
        reader = PdfReader(pdf_path)
        with open(txt_path, 'w', encoding='utf-8') as txt_file:
            for page in reader.pages:
                text = page.extract_text()
                if text:
                    txt_file.write(text + '\n')
    except Exception as e:
        return f"Conversion failed: {e}"

    return send_file(txt_path, as_attachment=True)
